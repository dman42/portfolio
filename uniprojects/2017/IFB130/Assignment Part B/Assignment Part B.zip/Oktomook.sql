CREATE DATABASE IF NOT EXISTS `Oktomook`;
USE `Oktomook`;

CREATE TABLE IF NOT EXISTS `Branch` ( branchNumber INT Primary Key,
  branchName TINYTEXT,
  streetNo MEDIUMINT,
  streetName TINYTEXT,
  branchCity TINYTEXT,
  branchState TINYTEXT,
  numberEmployees SMALLINT
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `Publisher` ( publisherCode INT Primary Key,
  publisherName TINYTEXT NOT NULL,
  publisherCity TINYTEXT,
  publisherState ENUM ('QLD', 'VIC', 'NSW', 'WA', 'TAS', 'NT', 'SA')
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `Author` ( authorID INT Primary Key,
  firstName TINYTEXT,
  lastName TINYTEXT
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `Book` ( ISBN BIGINT(13) ZEROFILL Primary Key,
  title TINYTEXT NOT NULL,
  publisherCode INT,
  genre ENUM ('Non-Fiction', 'Science Fiction', 'Fantasy', 'Crime', 'Mystery', 'Young Adult',
'Romance', 'General Fiction'),
  retailPrice DECIMAL,
  paperBack ENUM ('False', 'True') NOT NULL,
  Foreign Key (publisherCode) references Publisher(publisherCode)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `Wrote` ( ISBN BIGINT(13) ZEROFILL,
  authorID INT,
  sequenceNumber INT,
  Primary Key (ISBN, authorID),
  Foreign Key (ISBN) references Book(ISBN),
  Foreign Key (authorID) references Author(authorID)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `Inventory` ( ISBN BIGINT(13) ZEROFILL,
  branchNumber INT,
  quantityInStock INT DEFAULT 0,
  Primary Key (ISBN, branchNumber),
  Foreign Key (ISBN) references Book(ISBN),
  Foreign Key (branchNumber) references Branch(branchNumber)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;