Name:David McClarty
Student ID:n9939768


Please indicate for each question/task whether it is attempted/works/not attempted. 
If you have attempted it but it doesn't run successfully select 'attempted', if it runs then select 'works', otherwise select 'not attempted.
For Task 5 select either attempted/not attempted.

--------
Task 1
--------
Create Database: Works
Create Tables: Works
All Works

--------
Task 2
--------
Q1. Works
Q2. Works
Q3. Works
Q4. Works
Q5. Works

--------
Task 3
--------
Insert: Works
Delete: Works
Update: Works

--------
Task 4
--------
Create Index: Works
Create View: Works

Task 5: Attempted